#!/bin/sh

v2raya --version | grep "$PKG_VERSION"
