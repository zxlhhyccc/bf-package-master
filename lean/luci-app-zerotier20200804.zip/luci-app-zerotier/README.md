# luci-app-zerotier

你不在乎网络安全，可我在乎<br>
与lean原版相比使用了op自带的防火墙，并增添了流量权限控制