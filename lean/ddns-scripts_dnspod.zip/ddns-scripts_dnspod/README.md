# ddns-scripts_dnspod
支持同一域名同时使用A/AAAA记录
